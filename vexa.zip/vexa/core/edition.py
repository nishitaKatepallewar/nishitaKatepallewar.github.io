"""Which edition of Vexa this is.

The repo is always the full edition. `bash vexa/build.sh --free` builds vexa-free.zip
from a copy with FREE set to True here and only the presets in FREE_PRESETS.
"""

FREE = True

# The only built-in presets the free edition offers.
FREE_PRESETS = ("general",)
